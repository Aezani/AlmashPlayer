package com.ali.almashplayer;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(
        entities = {
                DownloadEntity.class,
                ShowEntity.class,
                LibraryShowEntity.class
        },
        version = 2,
        exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract DownloadDao downloadDao();
    public abstract ShowDao showDao();
    public abstract LibraryShowDao libraryShowDao();

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "almash_db"
                            )
                            // لأن القاعدة تُستخدم ككاش فقط، حذفها وإعادة إنشائها عند تغيير السكيمة مقبول
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
