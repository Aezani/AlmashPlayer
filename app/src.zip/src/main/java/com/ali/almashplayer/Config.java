package com.ali.almashplayer;

public class Config {

    private static final String BASE_URL = "http://192.168.20.30:32400";
    private static final String TOKEN = "66cEq5Eebq1_zUstysq_"; // غيّرها لو احتجت

    public static String getBaseUrl() {
        return BASE_URL;
    }

    // تُستخدم في PlexApiClient لبناء path مع التوكن
    public static String withToken(String path) {
        if (!path.startsWith("/")) {
            path = "/" + path;
        }
        return path + "?X-Plex-Token=" + TOKEN;
    }

    // تُستخدم في MovieGridAdapter لإضافة التوكن إلى رابط الصورة
    public static String getTokenQuery() {
        return "?X-Plex-Token=" + TOKEN;
    }
}
