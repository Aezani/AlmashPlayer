package com.ali.almashplayer;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.List;

/**
 * تبويب / شاشة قائمة التحميلات داخل التطبيق
 */
public class DownloadsFragment extends Fragment
        implements DownloadsAdapter.OnDownloadActionListener {

    private RecyclerView recyclerDownloads;
    private DownloadsAdapter adapter;

    // نستخدم القائمة المشتركة من DownloadsRepository
    private List<DownloadItem> downloads = DownloadsRepository.DOWNLOADS;

    // مرجع ثابت للـ Adapter ليستخدمه PlexRangeDownloader في تحديث العناصر
    public static DownloadsAdapter currentAdapter;

    public DownloadsFragment() {
        // مطلوب كونستركتور فارغ
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_downloads, container, false);

        recyclerDownloads = view.findViewById(R.id.recyclerDownloads);
        recyclerDownloads.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new DownloadsAdapter(downloads, this);
        currentAdapter = adapter;
        recyclerDownloads.setAdapter(adapter);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // تحميل من Room في خلفية، ثم تحديث الـ UI
        DownloadsRepository.loadFromDbAsync(requireContext(), () -> {
            if (adapter != null && isAdded()) {
                requireActivity().runOnUiThread(() -> adapter.notifyDataSetChanged());
            }
        });
    }

    @Override
    public void onResumeClicked(DownloadItem item) {
        if (getContext() == null) return;

        // التأكد من وجود ملف يمكن الاستئناف منه
        String path = item.getFilePath();
        if (path == null || path.isEmpty()) {
            Toast.makeText(getContext(), "لا يوجد ملف للاستئناف", Toast.LENGTH_SHORT).show();
            return;
        }

        File destFile = new File(path);
        if (!destFile.exists()) {
            Toast.makeText(getContext(), "الملف غير موجود على الجهاز", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(getContext(), "استئناف: " + item.getTitle(), Toast.LENGTH_SHORT).show();

        // إلغاء الإيقاف وتحديث الحالة
        item.setCancelled(false);
        item.setStatus(DownloadItem.STATUS_DOWNLOADING);
        DownloadsRepository.updateDownloadAsync(getContext(), item, () -> {
            if (adapter != null && isAdded()) {
                requireActivity().runOnUiThread(() -> adapter.notifyDataSetChanged());
            }
        });

        // بدء / استئناف التحميل من نفس الملف (سيكمل من حجمه الحالي)
        PlexRangeDownloader.startOrResumeDownload(requireContext(), item, destFile);
    }

    @Override
    public void onPauseClicked(DownloadItem item) {
        if (getContext() == null) return;

        // إيقاف التحميل من ناحية المنطق + إلغاء اتصال الشبكة
        item.setCancelled(true);
        item.setStatus(DownloadItem.STATUS_PAUSED);
        DownloadsRepository.updateDownloadAsync(getContext(), item, () -> {
            if (adapter != null && isAdded()) {
                requireActivity().runOnUiThread(() -> adapter.notifyDataSetChanged());
            }
        });

        // إلغاء الـ Call الحالي (سيؤدي إلى خروج read() فوراً)
        PlexRangeDownloader.cancelCurrentCall();

        Toast.makeText(getContext(), "إيقاف: " + item.getTitle(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDeleteClicked(DownloadItem item) {
        DownloadsRepository.deleteDownloadAsync(requireContext(), item, () -> {
            if (adapter != null && isAdded()) {
                requireActivity().runOnUiThread(() -> adapter.notifyDataSetChanged());
            }
        });
        Toast.makeText(getContext(), "حذف: " + item.getTitle(), Toast.LENGTH_SHORT).show();
    }
}
