package com.ali.almashplayer;

import android.app.Activity;
import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DownloadsRepository {

    public static final List<DownloadItem> DOWNLOADS = new ArrayList<>();

    public static void loadFromDbAsync(Context context, Runnable onDone) {
        new Thread(() -> {
            AppDatabase db = AppDatabase.getInstance(context.getApplicationContext());
            List<DownloadEntity> entities = db.downloadDao().getAll();

            synchronized (DOWNLOADS) {
                DOWNLOADS.clear();
                for (DownloadEntity e : entities) {
                    DownloadItem item = new DownloadItem(
                            e.id,
                            e.title,
                            e.url,
                            e.thumbUrl
                    );
                    item.setStatus(e.status);
                    item.setProgress(e.progress);
                    item.setDownloadId(e.downloadId);
                    item.setFilePath(e.filePath);
                    // لن نحمّل cancelled/totalBytes/downloadedBytes من DB الآن
                    DOWNLOADS.add(item);
                }
            }

            if (onDone != null) {
                onDone.run();
            }
        }).start();
    }

    public static void addDownloadAsync(Context context, DownloadItem item, Runnable onDone) {
        new Thread(() -> {
            AppDatabase db = AppDatabase.getInstance(context.getApplicationContext());

            DownloadEntity e = new DownloadEntity();
            e.title = item.getTitle();
            e.url = item.getUrl();
            e.thumbUrl = item.getThumbUrl();
            e.status = item.getStatus();
            e.progress = item.getProgress();
            e.downloadId = item.getDownloadId();
            e.filePath = item.getFilePath();

            long newId = db.downloadDao().insert(e);
            item.setId(newId);

            synchronized (DOWNLOADS) {
                DOWNLOADS.add(0, item);
            }

            if (onDone != null) {
                onDone.run();
            }
        }).start();
    }

    public static void updateDownloadAsync(Context context, DownloadItem item, Runnable onDone) {
        new Thread(() -> {
            AppDatabase db = AppDatabase.getInstance(context.getApplicationContext());

            DownloadEntity e = new DownloadEntity();
            e.id = item.getId();
            e.title = item.getTitle();
            e.url = item.getUrl();
            e.thumbUrl = item.getThumbUrl();
            e.status = item.getStatus();
            e.progress = item.getProgress();
            e.downloadId = item.getDownloadId();
            e.filePath = item.getFilePath();

            db.downloadDao().update(e);

            if (onDone != null) {
                onDone.run();
            }
        }).start();
    }

    public static void deleteDownloadAsync(Context context, DownloadItem item, Runnable onDone) {
        new Thread(() -> {

            // 1) حذف الملف من التخزين إن كان موجوداً
            try {
                String path = item.getFilePath();
                if (path != null && !path.isEmpty()) {
                    File f = new File(path);
                    if (f.exists()) {
                        // لا يهمنا نتيجة الحذف الآن، المهم المحاولة
                        f.delete();
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            // 2) حذف من Room
            AppDatabase db = AppDatabase.getInstance(context.getApplicationContext());

            DownloadEntity e = new DownloadEntity();
            e.id = item.getId();
            e.title = item.getTitle();
            e.url = item.getUrl();
            e.thumbUrl = item.getThumbUrl();
            e.status = item.getStatus();
            e.progress = item.getProgress();
            e.downloadId = item.getDownloadId();
            e.filePath = item.getFilePath();

            db.downloadDao().delete(e);

            // 3) حذف من القائمة في الذاكرة
            synchronized (DOWNLOADS) {
                DOWNLOADS.remove(item);
            }

            if (onDone != null) {
                onDone.run();
            }
        }).start();
    }

    // ====== دوال Sync لمراقبة التحميلات من DownloadsMonitor ======

    public static List<DownloadEntity> getActiveDownloadsSync(Context context) {
        AppDatabase db = AppDatabase.getInstance(context.getApplicationContext());
        return db.downloadDao().getActiveDownloads(
                DownloadItem.STATUS_DOWNLOADING,
                DownloadItem.STATUS_PAUSED
        );
    }

    public static void updateEntitySync(Context context, DownloadEntity e) {
        AppDatabase db = AppDatabase.getInstance(context.getApplicationContext());
        db.downloadDao().update(e);

        synchronized (DOWNLOADS) {
            for (DownloadItem item : DOWNLOADS) {
                if (item.getId() == e.id) {
                    item.setStatus(e.status);
                    item.setProgress(e.progress);
                    item.setDownloadId(e.downloadId);
                    item.setFilePath(e.filePath);
                    break;
                }
            }
        }
    }

    // ====== دالة لبدء التحميل عبر PlexDownloadManager ======

    public static void startInternalDownloadAsync(Activity activity, DownloadItem item, Runnable onDone) {
        new Thread(() -> {
            Context appCtx = activity.getApplicationContext();
            AppDatabase db = AppDatabase.getInstance(appCtx);

            if (item.getId() == 0) {
                item.setStatus(DownloadItem.STATUS_DOWNLOADING);
                item.setProgress(0);

                DownloadEntity e = new DownloadEntity();
                e.title = item.getTitle();
                e.url = item.getUrl();
                e.thumbUrl = item.getThumbUrl();
                e.status = item.getStatus();
                e.progress = item.getProgress();
                e.downloadId = 0;
                e.filePath = item.getFilePath();

                long newId = db.downloadDao().insert(e);
                item.setId(newId);

                synchronized (DOWNLOADS) {
                    DOWNLOADS.add(0, item);
                }
            }

            if (onDone != null) {
                onDone.run();
            }

            PlexDownloadManager.startDownload(activity, item);
        }).start();
    }
}
