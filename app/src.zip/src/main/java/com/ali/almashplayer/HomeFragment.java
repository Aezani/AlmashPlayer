package com.ali.almashplayer;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private ImageView imgHero;
    private TextView txtHeroTitle, txtHeroSubtitle;
    private Button btnHeroPlay;
    private RecyclerView recyclerHomeRows;

    private List<HomeRow> rows = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);

        imgHero = v.findViewById(R.id.imgHero);
        txtHeroTitle = v.findViewById(R.id.txtHeroTitle);
        txtHeroSubtitle = v.findViewById(R.id.txtHeroSubtitle);
        btnHeroPlay = v.findViewById(R.id.btnHeroPlay);
        recyclerHomeRows = v.findViewById(R.id.recyclerHomeRows);

        setupDummyHero();
        setupDummyRows();

        recyclerHomeRows.setLayoutManager(
                new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        HomeParentAdapter adapter = new HomeParentAdapter(rows, item -> {
            Toast.makeText(getContext(),
                    "تشغيل: " + item.getName(),
                    Toast.LENGTH_SHORT).show();
            // لاحقاً: فتح PlayerActivity مع بيانات Plex
        });
        recyclerHomeRows.setAdapter(adapter);

        btnHeroPlay.setOnClickListener(view -> {
            Toast.makeText(getContext(),
                    "تشغيل البوستر الرئيسي",
                    Toast.LENGTH_SHORT).show();
            // لاحقاً: اختيار عنصر حقيقي وتشغيله
        });

        return v;
    }

    private void setupDummyHero() {
        txtHeroTitle.setText("The Way Out (2022)");
        txtHeroSubtitle.setText("وصف تجريبي للفيلم/المسلسل يظهر هنا.");
        // لاحقاً: تحميل صورة من Plex
    }

    private void setupDummyRows() {
        rows.clear();

        List<HomeItem> recent = new ArrayList<>();
        recent.add(new HomeItem("1", "Movie 1"));
        recent.add(new HomeItem("2", "Movie 2"));
        recent.add(new HomeItem("3", "Movie 3"));

        List<HomeItem> popular = new ArrayList<>();
        popular.add(new HomeItem("4", "Popular 1"));
        popular.add(new HomeItem("5", "Popular 2"));
        popular.add(new HomeItem("6", "Popular 3"));

        rows.add(new HomeRow("الأفلام المضافة حديثًا", recent));
        rows.add(new HomeRow("الأفلام الأكثر مشاهدة", popular));
    }
}
