package com.ali.almashplayer;

public class HomeItem {
    private String id;
    private String name;

    public HomeItem(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
