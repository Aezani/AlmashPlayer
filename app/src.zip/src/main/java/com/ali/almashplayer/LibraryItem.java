package com.ali.almashplayer;

public class LibraryItem {
    private String ratingKey;
    private String title;
    private String year;
    private String thumb;   // مسار الصورة من Plex
    private String type;    // movie / show / episode

    public LibraryItem(String ratingKey, String title, String year, String thumb, String type) {
        this.ratingKey = ratingKey;
        this.title = title;
        this.year = year;
        this.thumb = thumb;
        this.type = type;
    }

    public String getRatingKey() {
        return ratingKey;
    }

    public String getTitle() {
        return title;
    }

    public String getYear() {
        return year;
    }

    public String getThumb() {
        return thumb;
    }

    public String getType() {
        return type;
    }
}
