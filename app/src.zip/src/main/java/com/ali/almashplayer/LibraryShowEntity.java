package com.ali.almashplayer;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * كاش للمسلسلات في قسم معيّن من Plex
 */
@Entity(tableName = "library_shows")
public class LibraryShowEntity {

    @PrimaryKey
    @NonNull
    public String ratingKey;   // مفتاح المسلسل من Plex

    public String sectionKey;  // قسم Plex (مثلاً مسلسل عربي / أجنبي...)
    public String title;
    public String year;
    public String thumb;       // مسار الصورة من Plex

    public long updatedAt;     // آخر تحديث من السيرفر (ms)
}
