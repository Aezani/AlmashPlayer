package com.ali.almashplayer;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_MEDIA_PERMISSIONS = 1001;

    private BottomNavigationView bottomNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigation = findViewById(R.id.bottom_navigation);
        bottomNavigation.setOnItemSelectedListener(this::onNavItemSelected);

        // أول شاشة افتراضياً: الرئيسية
        bottomNavigation.setSelectedItemId(R.id.nav_home);
        loadFragment(new HomeFragment());

        // إعداد التفضيلات لأول تشغيل
        SharedPreferences prefs = getSharedPreferences("almash_prefs", MODE_PRIVATE);
        boolean firstRun = prefs.getBoolean("first_run", true);

        // طلب أذونات الوسائط / التخزين
        if (!hasStoragePermissions()) {
            requestStoragePermissions();
        }

        // أول تشغيل: فقط علّم الفلاج، ويمكن لاحقاً تفعيل prewarmShowsCache لو أحببت
        if (firstRun) {
            prefs.edit().putBoolean("first_run", false).apply();
            // يمكن لاحقاً استدعاء prewarmShowsCache() هنا بعد ضبطها مع ShowsListRepository
            // prewarmShowsCache();
        }

        // تحميل قائمة التحميلات من Room إلى الذاكرة (لشاشة التحميلات)
        DownloadsRepository.loadFromDbAsync(this, null);
    }

    // ================== التنقل بين الصفحات ==================

    private boolean onNavItemSelected(@NonNull MenuItem item) {
        Fragment selected = null;
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            selected = new HomeFragment();
        } else if (id == R.id.nav_movies) {
            selected = new MoviesFragment();
        } else if (id == R.id.nav_series) {
            selected = new SeriesFragment();
        } else if (id == R.id.nav_downloads) {
            selected = new DownloadsFragment();
        }

        if (selected != null) {
            loadFragment(selected);
            return true;
        }
        return false;
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    // ================== أذونات التخزين / الوسائط ==================

    private boolean hasStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                    == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    == PackageManager.PERMISSION_GRANTED;
        } else {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.READ_MEDIA_VIDEO,
                            Manifest.permission.READ_MEDIA_IMAGES
                    },
                    REQ_MEDIA_PERMISSIONS
            );
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    },
                    REQ_MEDIA_PERMISSIONS
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MEDIA_PERMISSIONS) {
            boolean granted = true;
            for (int r : grantResults) {
                if (r != PackageManager.PERMISSION_GRANTED) {
                    granted = false;
                    break;
                }
            }
            if (!granted) {
                Toast.makeText(this,
                        "لن يعمل التحميل بدون منح إذن الوصول للوسائط",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    // ================== تهيئة الكاش من Plex (اختيارية) ==================
    // يمكن تفعيلها لاحقاً بعد ضبط ShowsListRepository / الفلاتر

//    private void prewarmShowsCache() {
//        new Thread(() -> {
//            try {
//                PlexApiClient client = new PlexApiClient();
//                java.util.List<LibrarySection> sections = client.getLibrarySections();
//                ShowsListRepository repo = new ShowsListRepository(this);
//
//                for (LibrarySection s : sections) {
//                    if (!"show".equals(s.getType())) continue;
//
//                    repo.getShowsForSectionAsync(
//                            s.getKey(),
//                            "الكل (أ - ي)",   // عدّل النص حسب الفلتر الفعلي لو اختلف
//                            null,
//                            null
//                    );
//                    repo.getShowsForSectionAsync(
//                            s.getKey(),
//                            "المضاف حديثًا",
//                            null,
//                            null
//                    );
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }).start();
//    }
}
