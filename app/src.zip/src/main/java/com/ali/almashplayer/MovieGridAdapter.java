package com.ali.almashplayer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class MovieGridAdapter extends RecyclerView.Adapter<MovieGridAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(LibraryItem item);
    }

    private List<LibraryItem> items;
    private OnItemClickListener listener;

    public MovieGridAdapter(List<LibraryItem> items, OnItemClickListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_movie_grid, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LibraryItem item = items.get(position);

        holder.txtTitle.setText(item.getTitle());
        holder.txtYear.setText(item.getYear() != null ? item.getYear() : "");

        // تحميل البوستر من Plex
        if (item.getThumb() != null) {
            // Config.getBaseUrl() مثل: http://192.168.20.30:32400/
            String imageUrl = Config.getBaseUrl()
                    + item.getThumb()
                    + Config.getTokenQuery(); // يرجّع ?X-Plex-Token=...

            Glide.with(holder.itemView.getContext())
                    .load(imageUrl)
                    .placeholder(android.R.color.darker_gray)
                    .centerCrop()
                    .into(holder.imgPoster);
        } else {
            holder.imgPoster.setImageResource(android.R.color.darker_gray);
        }

        holder.itemView.setOnClickListener(v -> listener.onItemClick(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imgPoster;
        TextView txtTitle;
        TextView txtYear;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgPoster = itemView.findViewById(R.id.imgMoviePoster);
            txtTitle = itemView.findViewById(R.id.txtMovieTitle);
            txtYear = itemView.findViewById(R.id.txtMovieYear);
        }
    }
}
