package com.ali.almashplayer;

import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class MoviesFragment extends Fragment {

    private TabLayout tabLayout;
    private RecyclerView recyclerMovies;
    private ImageButton btnSearch, btnFilter;

    private MovieGridAdapter adapter;
    private List<LibraryItem> items = new ArrayList<>();

    // الأقسام التي تُجلب من Plex (type = movie)
    private List<LibrarySection> movieSections = new ArrayList<>();

    private PlexApiClient plexApiClient = new PlexApiClient();
    private String currentSectionKey = null; // لا شيء حتى يتم تحميل الأقسام

    // وضع البحث: لو true لا نعيد تحميل القائمة تلقائياً عند تغيير التبويب إلا عندما يختار المستخدم فلتر جديد
    private boolean isSearchMode = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_movies, container, false);

        tabLayout = v.findViewById(R.id.tabMoviesCategories);
        recyclerMovies = v.findViewById(R.id.recyclerMovies);
        btnSearch = v.findViewById(R.id.btnSearchMovies);
        btnFilter = v.findViewById(R.id.btnFilterMovies);

        recyclerMovies.setLayoutManager(new GridLayoutManager(getContext(), 3));

        adapter = new MovieGridAdapter(items, item -> {
            Toast.makeText(getContext(),
                    "تشغيل: " + item.getTitle(),
                    Toast.LENGTH_SHORT).show();
            // TODO: فتح PlayerActivity مع Stream من Plex
        });
        recyclerMovies.setAdapter(adapter);

        btnSearch.setOnClickListener(view -> showSearchDialog());
        btnFilter.setOnClickListener(view -> showFilterDialog());

        // أولاً: تحميل الأقسام من السيرفر
        loadMovieSections();

        return v;
    }

    /**
     * جلب مكتبات Plex من السيرفر وتصفية مكتبات الأفلام فقط
     */
    private void loadMovieSections() {
        new AsyncTask<Void, Void, List<LibrarySection>>() {

            private Exception error;

            @Override
            protected List<LibrarySection> doInBackground(Void... voids) {
                try {
                    List<LibrarySection> all = plexApiClient.getLibrarySections();
                    List<LibrarySection> movies = new ArrayList<>();
                    for (LibrarySection s : all) {
                        if ("movie".equals(s.getType())) {
                            movies.add(s);
                        }
                    }
                    return movies;
                } catch (Exception e) {
                    error = e;
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<LibrarySection> result) {
                if (!isAdded()) return;

                if (error != null || result == null || result.isEmpty()) {
                    // لا اتصال أو لا توجد مكتبات أفلام
                    Toast.makeText(getContext(),
                            "تعذّر تحميل مكتبات الأفلام من Plex",
                            Toast.LENGTH_LONG).show();
                    tabLayout.removeAllTabs();
                    currentSectionKey = null;
                    items.clear();
                    adapter.notifyDataSetChanged();
                    return;
                }

                movieSections.clear();
                movieSections.addAll(result);
                setupTabsFromSections();
            }
        }.execute();
    }

    /**
     * إنشاء Tabs ديناميكياً من مكتبات Plex (type=movie)
     */
    private void setupTabsFromSections() {
        tabLayout.removeAllTabs();

        for (int i = 0; i < movieSections.size(); i++) {
            LibrarySection s = movieSections.get(i);
            tabLayout.addTab(tabLayout.newTab().setText(s.getTitle()), i);
        }

        // اختيار أول مكتبة كافتراضي
        LibrarySection first = movieSections.get(0);
        currentSectionKey = first.getKey();
        if (tabLayout.getTabCount() > 0) {
            tabLayout.getTabAt(0).select();
        }

        // تحميل عناصر أول قسم
        isSearchMode = false; // نبدأ من وضع عادي
        loadMovies(currentSectionKey, "الكل (أ - ي)", null);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                if (position >= 0 && position < movieSections.size()) {
                    currentSectionKey = movieSections.get(position).getKey();
                    // عند تغيير التبويب نخرج من وضع البحث
                    isSearchMode = false;
                    loadMovies(currentSectionKey, "الكل (أ - ي)", null);
                }
            }

            @Override public void onTabUnselected(TabLayout.Tab tab) { }

            @Override public void onTabReselected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                if (position >= 0 && position < movieSections.size()) {
                    currentSectionKey = movieSections.get(position).getKey();
                    // إعادة اختيار التبويب أيضاً تلغي البحث
                    isSearchMode = false;
                    loadMovies(currentSectionKey, "الكل (أ - ي)", null);
                }
            }
        });
    }

    // واجهة مبسّطة تستدعى بدون سنة
    private void loadMovies(String sectionKey, String mode) {
        loadMovies(sectionKey, mode, null);
    }

    // تحميل الأفلام مع فلترة اختيارية بالسنة
    private void loadMovies(String sectionKey, String mode, @Nullable String yearFilter) {
        if (sectionKey == null) {
            // لا توجد مكتبة مختارة (مثلاً فشل في تحميل الأقسام)
            return;
        }

        new AsyncTask<String, Void, List<LibraryItem>>() {

            private Exception error;

            @Override
            protected List<LibraryItem> doInBackground(String... params) {
                String key = params[0];
                String selectedMode = params[1];
                String year = params.length > 2 ? params[2] : null;

                try {
                    if ("المضاف حديثًا".equals(selectedMode)) {
                        return plexApiClient.getRecentlyAdded(key);
                    } else if ("السنة".equals(selectedMode) && year != null && !year.isEmpty()) {
                        String sortQuery = "?year=" + year + "&sort=titleSort:asc";
                        return plexApiClient.getLibraryItems(key, sortQuery);
                    } else {
                        return plexApiClient.getLibraryItems(
                                key,
                                "?sort=titleSort:asc");
                    }
                } catch (Exception e) {
                    error = e;
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<LibraryItem> result) {
                if (!isAdded()) return;

                if (error != null || result == null) {
                    Toast.makeText(getContext(),
                            "Error: " + (error != null ? error.getMessage() : "null result"),
                            Toast.LENGTH_LONG).show();
                    return;
                }
                items.clear();
                items.addAll(result);
                adapter.notifyDataSetChanged();
            }
        }.execute(sectionKey, mode, yearFilter != null ? yearFilter : "");
    }

    private void showFilterDialog() {
        if (currentSectionKey == null) {
            Toast.makeText(getContext(),
                    "لم يتم تحميل الأقسام بعد",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        String[] options = new String[]{
                "الكل (أ - ي)",
                "المضاف حديثًا",
                "السنة"
        };

        new AlertDialog.Builder(getContext())
                .setTitle("تصفح بحسب")
                .setItems(options, (dialog, which) -> {
                    String selected = options[which];

                    // أي فلتر جديد يلغي وضع البحث ويعيد تحميل حسب الفلتر
                    if ("السنة".equals(selected)) {
                        isSearchMode = false;
                        showYearDialog();
                    } else {
                        isSearchMode = false;
                        loadMovies(currentSectionKey, selected, null);
                    }
                })
                .show();
    }

    private void showYearDialog() {
        final EditText input = new EditText(getContext());
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("مثال: 2024");

        new AlertDialog.Builder(getContext())
                .setTitle("فلترة حسب السنة")
                .setView(input)
                .setPositiveButton("تطبيق", (dialog, which) -> {
                    String year = input.getText().toString().trim();
                    if (!year.isEmpty()) {
                        isSearchMode = false;
                        loadMovies(currentSectionKey, "السنة", year);
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void showSearchDialog() {
        if (currentSectionKey == null) {
            Toast.makeText(getContext(),
                    "لم يتم تحميل الأقسام بعد",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        final EditText input = new EditText(getContext());
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("اكتب اسم فيلم");

        new AlertDialog.Builder(getContext())
                .setTitle("بحث عن فيلم")
                .setView(input)
                .setPositiveButton("بحث", (dialog, which) -> {
                    String q = input.getText().toString().trim();
                    if (!q.isEmpty()) {
                        searchMovies(q);
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void searchMovies(String query) {
        new AsyncTask<String, Void, List<LibraryItem>>() {

            private Exception error;

            @Override
            protected List<LibraryItem> doInBackground(String... params) {
                String q = params[0];
                try {
                    return plexApiClient.searchInSection(currentSectionKey, q, "movie");
                } catch (Exception e) {
                    error = e;
                    return null;
                }
            }

            @Override
            protected void onPostExecute(List<LibraryItem> result) {
                if (!isAdded()) return;

                if (error != null || result == null) {
                    Toast.makeText(getContext(),
                            "Error: " + (error != null ? error.getMessage() : "null result"),
                            Toast.LENGTH_LONG).show();
                    return;
                }

                // فعّل وضع البحث حتى لا يتم استبدال النتائج مباشرة
                isSearchMode = true;

                items.clear();
                items.addAll(result);
                adapter.notifyDataSetChanged();
            }
        }.execute(query);
    }
}
