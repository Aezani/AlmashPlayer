package com.ali.almashplayer;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * كلاس بسيط للتعامل مع Plex API
 */
public class PlexApiClient {

    private final OkHttpClient client = new OkHttpClient();

    // ================== المكتبات ==================

    /**
     * جلب قائمة المكتبات
     */
    public List<LibrarySection> getLibrarySections() throws Exception {
        String url = Config.getBaseUrl() + Config.withToken("library/sections");
        Request request = new Request.Builder()
                .url(url)
                .addHeader("Connection", "close") // جرّب إغلاق keep-alive
                .build();


        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) {
            throw new IOException("HTTP error code: " + response.code());
        }

        InputStream inputStream = response.body().byteStream();
        List<LibrarySection> result = parseLibrarySectionsXml(inputStream);
        inputStream.close();
        return result;
    }

    private List<LibrarySection> parseLibrarySectionsXml(InputStream inputStream) throws Exception {
        List<LibrarySection> sections = new ArrayList<>();
        LibrarySection currentSection = null;

        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(inputStream, null);

        int eventType = parser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {

            if (eventType == XmlPullParser.START_TAG) {
                String name = parser.getName();

                if ("Directory".equals(name)) {
                    String key = parser.getAttributeValue(null, "key");
                    String title = parser.getAttributeValue(null, "title");
                    String type = parser.getAttributeValue(null, "type");

                    currentSection = new LibrarySection(key, title, type);
                    sections.add(currentSection);

                } else if ("Location".equals(name) && currentSection != null) {
                    String path = parser.getAttributeValue(null, "path");
                    currentSection.addPath(path);
                }
            }

            eventType = parser.next();
        }

        return sections;
    }

    // ================== عناصر المكتبة ==================

    /**
     * جلب عناصر مكتبة (أفلام/مسلسلات) من Section معيّن
     */
    public List<LibraryItem> getLibraryItems(String sectionKey, String sortQuery) throws Exception {
        String path = "library/sections/" + sectionKey + "/all";
        if (sortQuery != null && !sortQuery.isEmpty()) {
            path += sortQuery;
        }
        String url = Config.getBaseUrl() + Config.withToken(path);

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Connection", "close") // جرّب إغلاق keep-alive
                .build();

        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) {
            throw new IOException("HTTP error code: " + response.code());
        }

        InputStream inputStream = response.body().byteStream();
        List<LibraryItem> items = parseLibraryItemsXml(inputStream);
        inputStream.close();
        return items;
    }

    /**
     * جلب العناصر المضافة حديثاً من مكتبة معيّنة (عام، يرجع كما هو من Plex)
     */
    public List<LibraryItem> getRecentlyAdded(String sectionKey) throws Exception {
        String path = "library/sections/" + sectionKey + "/recentlyAdded";
        String url = Config.getBaseUrl() + Config.withToken(path);

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Connection", "close") // جرّب إغلاق keep-alive
                .build();

        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) {
            throw new IOException("HTTP error code: " + response.code());
        }

        InputStream inputStream = response.body().byteStream();
        List<LibraryItem> items = parseLibraryItemsXml(inputStream);
        inputStream.close();
        return items;
    }

    /**
     * جلب المسلسلات التي أضيفت لها حلقات حديثًا من قسم معيّن
     * النتيجة: كل مسلسل مرة واحدة فقط (من تجميع الحلقات).
     */
    public List<LibraryItem> getRecentlyAddedShows(String sectionKey) throws Exception {
        String path = "library/sections/" + sectionKey + "/recentlyAdded";
        String url = Config.getBaseUrl() + Config.withToken(path);

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Connection", "close") // جرّب إغلاق keep-alive
                .build();

        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) {
            throw new IOException("HTTP error code: " + response.code());
        }

        InputStream inputStream = response.body().byteStream();
        List<LibraryItem> shows = parseRecentlyAddedEpisodesToShows(inputStream);
        inputStream.close();
        return shows;
    }

    // ================== البحث داخل المكتبة (باستخدام /hubs/search) ==================

    /**
     * بحث نصي داخل مكتبة معيّنة باستخدام /hubs/search
     * wantedType: "movie" للأفلام، "show" للمسلسلات
     * القسم محدَّد بـ sectionKey، ولا يتم قبول عناصر من مكتبات أخرى.
     */
    public List<LibraryItem> searchInSection(String sectionKey, String query, String wantedType) throws Exception {
        String path = "hubs/search"
                + "?query=" + java.net.URLEncoder.encode(query, "UTF-8")
                + "&sectionId=" + sectionKey;
        String url = Config.getBaseUrl() + Config.withToken(path);

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Connection", "close") // جرّب إغلاق keep-alive
                .build();

        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) {
            throw new IOException("HTTP error code: " + response.code());
        }

        InputStream inputStream = response.body().byteStream();
        List<LibraryItem> items = parseHubsSearchXml(inputStream, wantedType, sectionKey);
        inputStream.close();
        return items;
    }

    /**
     * نسخة مختصرة (افتراضي أفلام عند استدعائها بدون تحديد نوع)
     */
    public List<LibraryItem> searchInSection(String sectionKey, String query) throws Exception {
        return searchInSection(sectionKey, query, "movie");
    }

    /**
     * تحليل استجابة /hubs/search واختيار Hub حسب type (movie أو show)
     * مع فلترة النتائج على مكتبة واحدة فقط (librarySectionID == sectionKeyFilter).
     */
    private List<LibraryItem> parseHubsSearchXml(InputStream inputStream,
                                                 String wantedType,
                                                 String sectionKeyFilter) throws Exception {
        List<LibraryItem> items = new ArrayList<>();

        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(inputStream, null);

        boolean insideWantedHub = false;

        int eventType = parser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {

            if (eventType == XmlPullParser.START_TAG) {
                String name = parser.getName();

                if ("Hub".equals(name)) {
                    String hubType = parser.getAttributeValue(null, "type");
                    insideWantedHub = (hubType != null && hubType.equals(wantedType));

                } else if (insideWantedHub) {
                    if ("movie".equals(wantedType) && "Video".equals(name)) {
                        String librarySectionId = parser.getAttributeValue(null, "librarySectionID");
                        if (librarySectionId == null || !librarySectionId.equals(sectionKeyFilter)) {
                            eventType = parser.next();
                            continue;
                        }

                        String ratingKey = parser.getAttributeValue(null, "ratingKey");
                        String title     = parser.getAttributeValue(null, "title");
                        String year      = parser.getAttributeValue(null, "year");
                        String thumb     = parser.getAttributeValue(null, "thumb");
                        String type      = parser.getAttributeValue(null, "type"); // "movie"

                        LibraryItem item = new LibraryItem(ratingKey, title, year, thumb, type);
                        // اختياري: لو أضفت حقل librarySectionId داخل LibraryItem
                        // item.setLibrarySectionId(librarySectionId);
                        items.add(item);

                    } else if ("show".equals(wantedType) && "Directory".equals(name)) {
                        String librarySectionId = parser.getAttributeValue(null, "librarySectionID");
                        if (librarySectionId == null || !librarySectionId.equals(sectionKeyFilter)) {
                            eventType = parser.next();
                            continue;
                        }

                        String ratingKey = parser.getAttributeValue(null, "ratingKey");
                        String title     = parser.getAttributeValue(null, "title");
                        String year      = parser.getAttributeValue(null, "year");
                        String thumb     = parser.getAttributeValue(null, "thumb");
                        String type      = parser.getAttributeValue(null, "type"); // "show"

                        LibraryItem item = new LibraryItem(ratingKey, title, year, thumb, type);
                        // item.setLibrarySectionId(librarySectionId);
                        items.add(item);
                    }
                }

            } else if (eventType == XmlPullParser.END_TAG) {
                String name = parser.getName();
                if ("Hub".equals(name)) {
                    insideWantedHub = false;
                }
            }

            eventType = parser.next();
        }

        return items;
    }

    /**
     * تحليل XML لعناصر مكتبة Plex (أفلام/مسلسلات/حلقات)
     */
    private List<LibraryItem> parseLibraryItemsXml(InputStream inputStream) throws Exception {
        List<LibraryItem> items = new ArrayList<>();

        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(inputStream, null);

        int eventType = parser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {

            if (eventType == XmlPullParser.START_TAG) {
                String name = parser.getName();

                if ("Video".equals(name) || "Directory".equals(name)) {
                    String ratingKey = parser.getAttributeValue(null, "ratingKey");
                    String title = parser.getAttributeValue(null, "title");
                    String year = parser.getAttributeValue(null, "year");
                    String thumb = parser.getAttributeValue(null, "thumb");
                    String type = parser.getAttributeValue(null, "type");

                    LibraryItem item = new LibraryItem(ratingKey, title, year, thumb, type);
                    items.add(item);
                }
            }

            eventType = parser.next();
        }

        return items;
    }

    /**
     * يحوّل قائمة حلقات (Video type="episode") إلى مسلسلات مميزة
     * باستخدام grandparentRatingKey / grandparentTitle / grandparentThumb.
     */
    private List<LibraryItem> parseRecentlyAddedEpisodesToShows(InputStream inputStream) throws Exception {
        Map<String, LibraryItem> map = new LinkedHashMap<>();

        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(inputStream, null);

        int eventType = parser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {

            if (eventType == XmlPullParser.START_TAG) {
                String name = parser.getName();

                if ("Video".equals(name)) {
                    String type = parser.getAttributeValue(null, "type");
                    if (type == null || !"episode".equals(type)) {
                        eventType = parser.next();
                        continue;
                    }

                    String showRatingKey = parser.getAttributeValue(null, "grandparentRatingKey");
                    String showTitle     = parser.getAttributeValue(null, "grandparentTitle");
                    String showThumb     = parser.getAttributeValue(null, "grandparentThumb");
                    String showYear      = parser.getAttributeValue(null, "year");

                    if (showRatingKey == null || showRatingKey.isEmpty()) {
                        eventType = parser.next();
                        continue;
                    }

                    if (!map.containsKey(showRatingKey)) {
                        LibraryItem item = new LibraryItem(
                                showRatingKey,
                                showTitle != null ? showTitle : "مسلسل بدون عنوان",
                                showYear,
                                showThumb,
                                "show"
                        );
                        map.put(showRatingKey, item);
                    }
                }
            }

            eventType = parser.next();
        }

        return new ArrayList<>(map.values());
    }

    // ================== تفاصيل المسلسل ==================

    /**
     * جلب تفاصيل مسلسل واحد من /library/metadata/{ratingKey}
     */
    public ShowInfo getShowDetails(String showRatingKey) throws Exception {
        String path = "library/metadata/" + showRatingKey;
        String url = Config.getBaseUrl() + Config.withToken(path);

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Connection", "close") // جرّب إغلاق keep-alive
                .build();

        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) {
            throw new IOException("HTTP error code: " + response.code());
        }

        InputStream inputStream = response.body().byteStream();
        ShowInfo info = parseShowDetailsXml(inputStream);
        inputStream.close();
        return info;
    }

    private ShowInfo parseShowDetailsXml(InputStream inputStream) throws Exception {
        ShowInfo info = new ShowInfo();

        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(inputStream, null);

        int eventType = parser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {

            if (eventType == XmlPullParser.START_TAG) {
                String name = parser.getName();

                if ("Directory".equals(name) || "Video".equals(name)) {

                    String type = parser.getAttributeValue(null, "type");
                    if (type != null && !"show".equals(type)) {
                        eventType = parser.next();
                        continue;
                    }

                    info.setRatingKey(parser.getAttributeValue(null, "ratingKey"));
                    info.setTitle(parser.getAttributeValue(null, "title"));
                    info.setYear(parser.getAttributeValue(null, "year"));
                    info.setSummary(parser.getAttributeValue(null, "summary"));
                    info.setThumb(parser.getAttributeValue(null, "thumb"));
                    info.setArt(parser.getAttributeValue(null, "art"));

                    String durationMs = parser.getAttributeValue(null, "duration");
                    if (durationMs != null && !durationMs.isEmpty()) {
                        try {
                            long ms = Long.parseLong(durationMs);
                            int minutes = (int) (ms / 1000 / 60);
                            info.setDuration(minutes + " دقيقة");
                        } catch (NumberFormatException ignored) { }
                    }

                    String childCount = parser.getAttributeValue(null, "childCount");
                    if (childCount != null && !childCount.isEmpty()) {
                        try {
                            info.setSeasonCount(Integer.parseInt(childCount));
                        } catch (NumberFormatException ignored) { }
                    }

                    break;
                }
            }

            eventType = parser.next();
        }

        return info;
    }

    // ================== مواسم المسلسل ==================

    /**
     * جلب مواسم مسلسل من /library/metadata/{showRatingKey}/children
     */
    public List<SeasonInfo> getShowSeasons(String showRatingKey) throws Exception {
        String path = "library/metadata/" + showRatingKey + "/children";
        String url = Config.getBaseUrl() + Config.withToken(path);

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Connection", "close") // جرّب إغلاق keep-alive
                .build();

        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) {
            throw new IOException("HTTP error code: " + response.code());
        }

        InputStream inputStream = response.body().byteStream();
        List<SeasonInfo> seasons = parseSeasonsXml(inputStream);
        inputStream.close();
        return seasons;
    }

    private List<SeasonInfo> parseSeasonsXml(InputStream inputStream) throws Exception {
        List<SeasonInfo> seasons = new ArrayList<>();

        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(inputStream, null);

        int eventType = parser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {

            if (eventType == XmlPullParser.START_TAG) {
                String name = parser.getName();

                if ("Directory".equals(name)) {
                    String type = parser.getAttributeValue(null, "type");
                    if (type != null && !"season".equals(type)) {
                        eventType = parser.next();
                        continue;
                    }

                    String title = parser.getAttributeValue(null, "title");
                    String idxStr = parser.getAttributeValue(null, "index");
                    int idx = -1;
                    if (idxStr != null && !idxStr.isEmpty()) {
                        try { idx = Integer.parseInt(idxStr); } catch (NumberFormatException ignored) { }
                    }

                    if (title != null && title.toLowerCase().contains("all episodes")) {
                        eventType = parser.next();
                        continue;
                    }
                    if (idx == 0) {
                        eventType = parser.next();
                        continue;
                    }

                    SeasonInfo s = new SeasonInfo();
                    s.setRatingKey(parser.getAttributeValue(null, "ratingKey"));
                    s.setParentRatingKey(parser.getAttributeValue(null, "parentRatingKey"));
                    s.setTitle(title);
                    s.setThumb(parser.getAttributeValue(null, "thumb"));
                    if (idx > 0) s.setIndex(idx);

                    String leafCount = parser.getAttributeValue(null, "leafCount");
                    if (leafCount != null && !leafCount.isEmpty()) {
                        try { s.setEpisodeCount(Integer.parseInt(leafCount)); } catch (NumberFormatException ignored) { }
                    }

                    seasons.add(s);
                }
            }

            eventType = parser.next();
        }

        return seasons;
    }

    // ================== حلقات الموسم ==================

    /**
     * جلب حلقات موسم من /library/metadata/{seasonRatingKey}/children
     */
    public List<EpisodeInfo> getSeasonEpisodes(String seasonRatingKey) throws Exception {
        String path = "library/metadata/" + seasonRatingKey + "/children";
        String url = Config.getBaseUrl() + Config.withToken(path);

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Connection", "close") // جرّب إغلاق keep-alive
                .build();

        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) {
            throw new IOException("HTTP error code: " + response.code());
        }

        InputStream inputStream = response.body().byteStream();
        List<EpisodeInfo> episodes = parseEpisodesXml(inputStream);
        inputStream.close();
        return episodes;
    }

    private List<EpisodeInfo> parseEpisodesXml(InputStream inputStream) throws Exception {
        List<EpisodeInfo> episodes = new ArrayList<>();

        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(inputStream, null);

        int eventType = parser.getEventType();
        EpisodeInfo current = null;

        while (eventType != XmlPullParser.END_DOCUMENT) {

            if (eventType == XmlPullParser.START_TAG) {
                String name = parser.getName();

                if ("Video".equals(name)) {
                    String type = parser.getAttributeValue(null, "type");
                    if (type != null && !"episode".equals(type)) {
                        eventType = parser.next();
                        continue;
                    }

                    current = new EpisodeInfo();
                    current.setRatingKey(parser.getAttributeValue(null, "ratingKey"));
                    current.setParentRatingKey(parser.getAttributeValue(null, "parentRatingKey"));
                    current.setTitle(parser.getAttributeValue(null, "title"));
                    current.setSummary(parser.getAttributeValue(null, "summary"));
                    current.setThumb(parser.getAttributeValue(null, "thumb"));

                    String idx = parser.getAttributeValue(null, "index");
                    if (idx != null && !idx.isEmpty()) {
                        try { current.setIndex(Integer.parseInt(idx)); } catch (NumberFormatException ignored) { }
                    }

                    String durationMs = parser.getAttributeValue(null, "duration");
                    if (durationMs != null && !durationMs.isEmpty()) {
                        try {
                            long ms = Long.parseLong(durationMs);
                            int minutes = (int) (ms / 1000 / 60);
                            current.setDuration(minutes + " دقيقة");
                        } catch (NumberFormatException ignored) { }
                    }

                    episodes.add(current);

                } else if ("Part".equals(name) && current != null) {
                    String key = parser.getAttributeValue(null, "key");
                    current.setPartKey(key);
                }

            }

            eventType = parser.next();
        }

        return episodes;
    }
}
