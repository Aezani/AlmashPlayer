package com.ali.almashplayer;

public class PlexConfig {
    public String serverUrl;
    public String token;
}