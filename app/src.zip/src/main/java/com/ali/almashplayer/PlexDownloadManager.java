package com.ali.almashplayer;

import android.app.Activity;
import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * مدير تحميل داخلي يعتمد OkHttp، يحفظ مباشرة في:
 * /storage/emulated/0/Download/AlmashDownloads/mash/<filename>.mp4
 * ويحدّث DownloadsRepository بالتقدّم والحالة.
 */
public class PlexDownloadManager {

    private static final String TAG = "PlexDownload";

    /**
     * يبدأ تحميل فيديو Plex باستخدام OkHttp في ثريد منفصل.
     * لا يستخدم ExoPlayer DownloadService.
     */
    public static long startDownload(Activity activity, DownloadItem item) {
        Context context = activity.getApplicationContext();

        String fileName = sanitizeFileName(item.getTitle()) + ".mp4";

        File downloadsRoot = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS
        );
        Log.d(TAG, "downloadsRoot=" + downloadsRoot.getAbsolutePath()
                + ", exists=" + downloadsRoot.exists());

        File almashRoot = new File(downloadsRoot, "AlmashDownloads");
        Log.d(TAG, "almashRoot(before) exists=" + almashRoot.exists()
                + ", path=" + almashRoot.getAbsolutePath());
        if (!almashRoot.exists()) {
            boolean almashOk = almashRoot.mkdirs();
            Log.d(TAG, "almashRoot.mkdirs() returned=" + almashOk
                    + ", exists(after)=" + almashRoot.exists());
        }

        File mashDir = new File(almashRoot, "mash");
        Log.d(TAG, "mashDir(before) exists=" + mashDir.exists()
                + ", path=" + mashDir.getAbsolutePath());
        if (!mashDir.exists()) {
            boolean mashOk = mashDir.mkdirs();
            Log.d(TAG, "mashDir.mkdirs() returned=" + mashOk
                    + ", exists(after)=" + mashDir.exists());
        }

        File destFile = new File(mashDir, fileName);
        String fullPath = destFile.getAbsolutePath();

        item.setFilePath(fullPath);
        item.setStatus(DownloadItem.STATUS_DOWNLOADING);
        item.setProgress(0);
        if (destFile.exists()) {
            item.setDownloadedBytes(destFile.length());
        } else {
            item.setDownloadedBytes(0);
        }

        Log.d(TAG, "startDownload (Range): url=" + item.getUrl());
        Log.d(TAG, "startDownload (Range): path=" + fullPath);

        DownloadsRepository.updateDownloadAsync(
                context,
                item,
                null
        );

        // بدء أو استئناف التحميل عبر Range Downloader
        PlexRangeDownloader.startOrResumeDownload(context, item, destFile);

        item.setDownloadId(0);
        return 0;
    }

    /**
     * التنفيذ الفعلي للتحميل باستخدام OkHttp.
     */
    private static void performDownload(Context context, DownloadItem item, File destFile) {
        OkHttpClient client = AlmashApplication.getInstance().getHttpClient();
        String url = item.getUrl();

        Request request = new Request.Builder()
                .url(url)
                .build();

        long totalBytes = 0;
        long downloadedBytes = 0;

        try {
            Call call = client.newCall(request);
            Response response = call.execute();

            if (!response.isSuccessful()) {
                Log.e(TAG, "HTTP error: " + response.code());
                item.setStatus(DownloadItem.STATUS_FAILED);
                DownloadsRepository.updateDownloadAsync(context, item, null);
                return;
            }

            ResponseBody body = response.body();
            if (body == null) {
                Log.e(TAG, "Empty response body");
                item.setStatus(DownloadItem.STATUS_FAILED);
                DownloadsRepository.updateDownloadAsync(context, item, null);
                return;
            }

            totalBytes = body.contentLength();
            item.setTotalBytes(totalBytes);

            InputStream in = body.byteStream();
            FileOutputStream out = new FileOutputStream(destFile);

            byte[] buffer = new byte[8192];
            int read;
            int lastProgress = 0;

            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
                downloadedBytes += read;
                item.setDownloadedBytes(downloadedBytes);

                if (totalBytes > 0) {
                    int progress = (int) ((downloadedBytes * 100) / totalBytes);
                    if (progress != lastProgress) {
                        lastProgress = progress;
                        item.setProgress(progress);
                        item.setStatus(DownloadItem.STATUS_DOWNLOADING);
                        DownloadsRepository.updateDownloadAsync(context, item, null);
                        Log.d(TAG, "download progress=" + progress + "%");
                    }
                } else {
                    // في حال لم يُرجع السيرفر content-length، أبقِ progress على 0 حتى النهاية
                    item.setProgress(0);
                }
            }

            out.flush();
            out.close();
            in.close();

            // اكتمل التحميل
            item.setStatus(DownloadItem.STATUS_COMPLETED);
            item.setProgress(100);
            item.setFilePath(destFile.getAbsolutePath());
            DownloadsRepository.updateDownloadAsync(context, item, null);

            Log.d(TAG, "download completed: " + destFile.getAbsolutePath());

        } catch (Exception e) {
            Log.e(TAG, "download error (OkHttp)", e);
            item.setStatus(DownloadItem.STATUS_FAILED);
            DownloadsRepository.updateDownloadAsync(context, item, null);

            // مؤقتًا لا نحذف الملف حتى نعرف كم حجم ما تم تحميله:
            // try {
            //     if (destFile.exists()) {
            //         //noinspection ResultOfMethodCallIgnored
            //         destFile.delete();
            //     }
            // } catch (Exception ignore) {
            // }
        }
    }

    private static String sanitizeFileName(String name) {
        if (name == null) return "video";
        return name.replaceAll("[\\\\/:*?\"<>|]", "_");
    }
}
