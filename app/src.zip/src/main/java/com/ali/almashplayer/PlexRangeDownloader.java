package com.ali.almashplayer;

import android.content.Context;
import android.os.Handler;
import android.util.Log;

import java.io.File;
import java.io.InputStream;
import java.io.RandomAccessFile;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Downloader يدعم الاستئناف عبر HTTP Range + دعم الإيقاف وتحديث الواجهة لحظياً.
 */
public class PlexRangeDownloader {

    private static final String TAG = "PlexRangeDownloader";

    // عدد المحاولات القصوى لكل تحميل
    private static final int MAX_RETRY = 3;

    // حفظ الـ Call الحالي لإمكانية إلغائه فوراً
    private static volatile Call currentCall;

    public static void startOrResumeDownload(Context context, DownloadItem item, File destFile) {
        // عند الاستئناف نتأكد أن الفلاغ ملغي
        item.setCancelled(false);
        new Thread(() -> runDownloadLoop(context, item, destFile)).start();
    }

    // تستدعى من زر الإيقاف لإلغاء اتصال الشبكة
    public static void cancelCurrentCall() {
        Call c = currentCall;
        if (c != null) {
            c.cancel();
        }
    }

    private static void runDownloadLoop(Context context, DownloadItem item, File destFile) {
        OkHttpClient client = AlmashApplication.getInstance().getHttpClient();
        String url = item.getUrl();

        int attempt = 0;
        boolean success = false;

        while (attempt < MAX_RETRY && !success) {
            // حجم الملف الموجود حالياً على القرص
            long downloadedBytes = destFile.exists() ? destFile.length() : 0;
            item.setDownloadedBytes(downloadedBytes);

            // لو تم إلغاء التحميل قبل بدء المحاولة الحالية نخرج
            if (item.isCancelled()) {
                Log.d(TAG, "download cancelled before attempt " + (attempt + 1));
                return;
            }

            attempt++;
            Log.d(TAG, "download attempt " + attempt + " for url=" + url);

            Response response = null;
            InputStream in = null;
            RandomAccessFile raf = null;

            try {
                long totalBytes = item.getTotalBytes();

                // نبني الطلب مع أو بدون Range حسب ما تم تحميله
                Request.Builder builder = new Request.Builder().url(url);
                if (downloadedBytes > 0) {
                    String range = "bytes=" + downloadedBytes + "-";
                    builder.header("Range", range);
                    Log.d(TAG, "using Range header: " + range);
                }

                Request request = builder.build();
                Call call = client.newCall(request);
                currentCall = call;

                response = call.execute();

                if (!response.isSuccessful()) {
                    Log.e(TAG, "HTTP error: " + response.code());
                    continue; // جرّب محاولة أخرى (ما دام لم يُلغَ)
                }

                ResponseBody body = response.body();
                if (body == null) {
                    Log.e(TAG, "Empty response body");
                    continue;
                }

                // contentLength هو حجم الجزء القادم فقط (في حالة Range)
                long contentLength = body.contentLength();
                if (contentLength > 0) {
                    if (downloadedBytes > 0) {
                        totalBytes = downloadedBytes + contentLength;
                    } else {
                        totalBytes = contentLength;
                    }
                    item.setTotalBytes(totalBytes); // مهم جداً لإظهار الحجم الكلي
                }

                in = body.byteStream();

                // نفتح الملف بشكل يسمح بالاستئناف
                raf = new RandomAccessFile(destFile, "rw");
                raf.seek(downloadedBytes);

                byte[] buffer = new byte[1024 * 256]; // 256KB
                int read;
                int lastProgress = item.getProgress();

                item.setStatus(DownloadItem.STATUS_DOWNLOADING);
                postItemUpdate(context, item); // أول تحديث

                while (true) {
                    // read قد يرمي استثناء إذا تم cancel() على الـ Call
                    read = in.read(buffer);
                    if (read == -1) {
                        break;
                    }

                    // فحص الإيقاف بعد كل قراءة
                    if (item.isCancelled()) {
                        Log.d(TAG, "download cancelled in loop, downloaded=" + downloadedBytes);
                        return;
                    }

                    raf.write(buffer, 0, read);
                    downloadedBytes += read;
                    item.setDownloadedBytes(downloadedBytes);

                    if (totalBytes > 0) {
                        int progress = (int) ((downloadedBytes * 100L) / totalBytes);
                        if (progress != lastProgress) {
                            lastProgress = progress;
                            item.setProgress(progress);
                            item.setStatus(DownloadItem.STATUS_DOWNLOADING);
                            postItemUpdate(context, item); // تحديث DB + UI
                            Log.d(TAG, "download progress=" + progress + "%");
                        }
                    } else {
                        // حتى لو لا نعرف totalBytes، حدّث القيمة المحمَّلة لكي لا تبقى 0 B
                        postItemUpdate(context, item);
                    }
                }

                // لو خرجنا من الحلقة بدون إلغاء، نتحقق من الاكتمال
                if (totalBytes > 0 && downloadedBytes < totalBytes && !item.isCancelled()) {
                    Log.w(TAG, "stream ended early: downloaded=" + downloadedBytes + " total=" + totalBytes);
                    continue;
                }

                // اكتمل التحميل (ولم يُلغَ)
                if (!item.isCancelled()) {
                    item.setStatus(DownloadItem.STATUS_COMPLETED);
                    item.setProgress(100);
                    item.setFilePath(destFile.getAbsolutePath());
                    item.setDownloadedBytes(downloadedBytes);
                    postItemUpdate(context, item);
                    Log.d(TAG, "download completed: " + destFile.getAbsolutePath());
                }

                success = true;

            } catch (Exception e) {
                // إذا الإلغاء من المستخدم (cancelCurrentCall أو cancelled=true) نخرج بلا محاولات أخرى
                if (item.isCancelled() || e instanceof java.net.SocketException) {
                    Log.d(TAG, "download cancelled by user with exception: " + e);
                    return;
                }
                Log.e(TAG, "download error (Range)", e);
            } finally {
                currentCall = null;
                try { if (raf != null) raf.close(); } catch (Exception ignore) {}
                try { if (in != null) in.close(); } catch (Exception ignore) {}
                if (response != null) response.close();
            }
        }

        // لو خرجنا بسبب فشل حقيقي وليس إلغاء
        if (!success && !item.isCancelled()) {
            item.setStatus(DownloadItem.STATUS_FAILED);
            postItemUpdate(context, item);
            Log.e(TAG, "download failed after " + MAX_RETRY + " attempts");
        }
    }

    // دالة مساعدة لتحديث الـ DB + UI لعنصر واحد
    private static void postItemUpdate(Context context, DownloadItem item) {
        DownloadsRepository.updateDownloadAsync(context, item, () -> {
            // التأكد أن العنصر في القائمة المشتركة يحمل نفس القيم (نفس المرجع الذي يستخدمه الـ Adapter)
            for (int i = 0; i < DownloadsRepository.DOWNLOADS.size(); i++) {
                DownloadItem it = DownloadsRepository.DOWNLOADS.get(i);
                if (it.getId() == item.getId()) {
                    it.setProgress(item.getProgress());
                    it.setStatus(item.getStatus());
                    it.setDownloadedBytes(item.getDownloadedBytes());
                    it.setTotalBytes(item.getTotalBytes());
                    it.setFilePath(item.getFilePath());
                    break;
                }
            }

            DownloadsAdapter adapter = DownloadsFragment.currentAdapter;

            Log.d(TAG, "postItemUpdate for id=" + item.getId()
                    + " progress=" + item.getProgress()
                    + " downloaded=" + item.getDownloadedBytes()
                    + " total=" + item.getTotalBytes()
                    + " adapter=" + adapter);

            if (adapter != null) {
                Handler h = new Handler(context.getMainLooper());
                h.post(() -> adapter.notifyItemChangedById(item.getId()));
            }
            // لو adapter == null، يكفي أن DownloadItem تم تحديثه في الذاكرة و Room،
            // وعند فتح شاشة التحميلات، onResume + notifyDataSetChanged ستعرض القيم الصحيحة.
        });
    }
}
