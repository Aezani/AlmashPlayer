package com.ali.almashplayer;

import android.content.Context;
import android.util.Log;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class RemoteConfigLoader {

    private static final String TAG = "RemoteConfigLoader";

    private static PlexConfig cachedConfig;

    public static void loadConfigAsync(Context context, Runnable onLoaded) {
        Log.d(TAG, "loadConfigAsync called");

        // لو محمّل من قبل استخدم الكاش
        if (cachedConfig != null) {
            Log.d(TAG, "using cached config: serverUrl=" + cachedConfig.serverUrl
                    + ", token=" + cachedConfig.token);
            if (onLoaded != null) onLoaded.run();
            return;
        }

        new Thread(() -> {
            try {
                String configUrl = "http://ms.mizzabi.com:88/plex-config.json";
                Log.d(TAG, "fetching config from " + configUrl);

                OkHttpClient client = AlmashApplication.getInstance().getHttpClient();
                Request request = new Request.Builder()
                        .url(configUrl)
                        .build();

                Response response = client.newCall(request).execute();
                Log.d(TAG, "config HTTP code=" + response.code());

                if (!response.isSuccessful() || response.body() == null) {
                    Log.e(TAG, "failed to load config, body=null or code!=200");
                    return;
                }

                String body = response.body().string();
                Log.d(TAG, "config raw body=" + body);

                PlexConfig config = new PlexConfig();
                config.serverUrl = extractValue(body, "server_url");
                config.token = extractValue(body, "token");

                Log.d(TAG, "parsed config: serverUrl=" + config.serverUrl
                        + ", token=" + config.token);

                if (config.serverUrl != null && config.token != null) {
                    cachedConfig = config;
                    Log.d(TAG, "config cached successfully");
                } else {
                    Log.e(TAG, "config missing fields server_url/token");
                }

            } catch (Exception e) {
                Log.e(TAG, "error loading config", e);
            }

            if (onLoaded != null) {
                onLoaded.run();
            }
        }).start();
    }

    public static PlexConfig getConfig() {
        return cachedConfig;
    }

    private static String extractValue(String json, String key) {
        String pattern = "\"" + key + "\"";
        int idx = json.indexOf(pattern);
        if (idx == -1) return null;
        int colon = json.indexOf(":", idx);
        if (colon == -1) return null;
        int firstQuote = json.indexOf("\"", colon + 1);
        int secondQuote = json.indexOf("\"", firstQuote + 1);
        if (firstQuote == -1 || secondQuote == -1) return null;
        return json.substring(firstQuote + 1, secondQuote);
    }
}
