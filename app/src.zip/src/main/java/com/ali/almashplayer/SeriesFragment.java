package com.ali.almashplayer;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class SeriesFragment extends Fragment {

    private TabLayout tabLayout;
    private RecyclerView recyclerSeries;
    private ImageButton btnSearch, btnFilter;

    private MovieGridAdapter adapter; // نستخدم نفس الأداپتر لعرض المسلسلات
    private final List<LibraryItem> items = new ArrayList<>();

    private final List<LibrarySection> showSections = new ArrayList<>();

    private PlexApiClient plexApiClient = new PlexApiClient();
    private ShowsListRepository showsListRepository;

    private String currentSectionKey = null;
    private String currentMode = "الكل (أ - ي)";
    private String currentYearFilter = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_series, container, false);

        tabLayout = v.findViewById(R.id.tabSeriesCategories);
        recyclerSeries = v.findViewById(R.id.recyclerSeries);
        btnSearch = v.findViewById(R.id.btnSearchSeries);
        btnFilter = v.findViewById(R.id.btnFilterSeries);

        recyclerSeries.setLayoutManager(new GridLayoutManager(getContext(), 3));

        adapter = new MovieGridAdapter(items, item -> {
            if (item == null || item.getRatingKey() == null || item.getRatingKey().isEmpty()) {
                Toast.makeText(getContext(),
                        "لا يمكن فتح هذا العنصر (ratingKey غير موجود)",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (!"show".equals(item.getType())) {
                Toast.makeText(getContext(),
                        "هذا ليس مسلسلاً: " + item.getTitle(),
                        Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(requireContext(), ShowDetailsActivity.class);
            intent.putExtra(ShowDetailsActivity.EXTRA_SHOW_RATING_KEY, item.getRatingKey());
            startActivity(intent);
        });
        recyclerSeries.setAdapter(adapter);

        showsListRepository = new ShowsListRepository(requireContext());

        btnSearch.setOnClickListener(view -> showSearchDialog());
        btnFilter.setOnClickListener(view -> showFilterDialog());

        loadShowSections();

        return v;
    }

    // ================= تحميل أقسام المسلسلات من Plex (كما هي) =================

    private void loadShowSections() {
        new Thread(() -> {
            Exception error = null;
            List<LibrarySection> result = null;
            try {
                List<LibrarySection> all = plexApiClient.getLibrarySections();
                List<LibrarySection> shows = new ArrayList<>();
                for (LibrarySection s : all) {
                    if ("show".equals(s.getType())) {
                        shows.add(s);
                    }
                }
                result = shows;
            } catch (Exception e) {
                error = e;
            }

            List<LibrarySection> finalResult = result;
            Exception finalError = error;

            if (!isAdded()) return;

            requireActivity().runOnUiThread(() -> {
                if (finalError != null || finalResult == null || finalResult.isEmpty()) {
                    Toast.makeText(getContext(),
                            "تعذّر تحميل مكتبات المسلسلات من Plex",
                            Toast.LENGTH_LONG).show();
                    tabLayout.removeAllTabs();
                    currentSectionKey = null;
                    items.clear();
                    adapter.notifyDataSetChanged();
                    return;
                }

                showSections.clear();
                showSections.addAll(finalResult);
                setupTabsFromSections();
            });
        }).start();
    }

    private void setupTabsFromSections() {
        tabLayout.removeAllTabs();

        for (int i = 0; i < showSections.size(); i++) {
            LibrarySection s = showSections.get(i);
            tabLayout.addTab(tabLayout.newTab().setText(s.getTitle()), i);
        }

        LibrarySection first = showSections.get(0);
        currentSectionKey = first.getKey();
        currentMode = "الكل (أ - ي)";
        currentYearFilter = null;

        if (tabLayout.getTabCount() > 0) {
            TabLayout.Tab firstTab = tabLayout.getTabAt(0);
            if (firstTab != null) firstTab.select();
        }

        loadSeriesWithCache(currentSectionKey, currentMode, currentYearFilter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                if (position >= 0 && position < showSections.size()) {
                    currentSectionKey = showSections.get(position).getKey();
                    currentMode = "الكل (أ - ي)";
                    currentYearFilter = null;
                    loadSeriesWithCache(currentSectionKey, currentMode, currentYearFilter);
                }
            }

            @Override public void onTabUnselected(TabLayout.Tab tab) { }

            @Override public void onTabReselected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                if (position >= 0 && position < showSections.size()) {
                    currentSectionKey = showSections.get(position).getKey();
                    loadSeriesWithCache(currentSectionKey, currentMode, currentYearFilter);
                }
            }
        });
    }

    // ================= الكاش + التحديث من Plex =================

    private void loadSeriesWithCache(String sectionKey, String mode, @Nullable String yearFilter) {
        if (sectionKey == null) return;

        currentMode = mode;
        currentYearFilter = yearFilter;

        showsListRepository.getShowsForSectionAsync(sectionKey, mode, yearFilter, (list, error) -> {
            if (!isAdded()) return;

            requireActivity().runOnUiThread(() -> {
                if (error != null && (list == null || list.isEmpty())) {
                    Toast.makeText(getContext(),
                            "Error: " + error.getMessage(),
                            Toast.LENGTH_LONG).show();
                    return;
                }
                if (list == null) return;

                items.clear();
                items.addAll(list);
                adapter.notifyDataSetChanged();
            });
        });
    }

    // ================= الفلترة / المود =================

    private void showFilterDialog() {
        if (currentSectionKey == null) {
            Toast.makeText(getContext(),
                    "لم يتم تحميل الأقسام بعد",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        String[] options = new String[]{
                "الكل (أ - ي)",
                "المضاف حديثًا",
                "السنة"
        };

        new AlertDialog.Builder(getContext())
                .setTitle("تصفح بحسب")
                .setItems(options, (dialog, which) -> {
                    String selected = options[which];

                    if ("السنة".equals(selected)) {
                        showYearDialog();
                    } else {
                        loadSeriesWithCache(currentSectionKey, selected, null);
                    }
                })
                .show();
    }

    private void showYearDialog() {
        final EditText input = new EditText(getContext());
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("مثال: 2024");

        new AlertDialog.Builder(getContext())
                .setTitle("فلترة حسب السنة")
                .setView(input)
                .setPositiveButton("تطبيق", (dialog, which) -> {
                    String year = input.getText().toString().trim();
                    if (!year.isEmpty()) {
                        loadSeriesWithCache(currentSectionKey, "السنة", year);
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    // ================= البحث (من Plex مباشرة، بدون كاش حالياً) =================

    private void showSearchDialog() {
        if (currentSectionKey == null) {
            Toast.makeText(getContext(),
                    "لم يتم تحميل الأقسام بعد",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        final EditText input = new EditText(getContext());
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("اكتب اسم مسلسل");

        new AlertDialog.Builder(getContext())
                .setTitle("بحث عن مسلسل")
                .setView(input)
                .setPositiveButton("بحث", (dialog, which) -> {
                    String q = input.getText().toString().trim();
                    if (!q.isEmpty()) {
                        searchSeries(q);
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void searchSeries(String query) {
        new Thread(() -> {
            Exception error = null;
            List<LibraryItem> result = null;
            try {
                result = plexApiClient.searchInSection(currentSectionKey, query, "show");
            } catch (Exception e) {
                error = e;
            }

            List<LibraryItem> finalResult = result;
            Exception finalError = error;

            if (!isAdded()) return;

            requireActivity().runOnUiThread(() -> {
                if (finalError != null || finalResult == null) {
                    Toast.makeText(getContext(),
                            "Error: " + (finalError != null ? finalError.getMessage() : "null result"),
                            Toast.LENGTH_LONG).show();
                    return;
                }
                items.clear();
                items.addAll(finalResult);
                adapter.notifyDataSetChanged();
            });
        }).start();
    }
}
