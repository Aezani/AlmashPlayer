package com.ali.almashplayer;

import android.content.Context;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Repository لقوائم المسلسلات في قسم معيّن:
 * - يقرأ من Room ككاش أولي لعرض سريع.
 * - يجلب دائماً من Plex حسب المود ويحدّث Room ثم يرجع النتيجة الأحدث.
 *
 * modes المدعومة:
 *  - "الكل (أ - ي)"   => كل المسلسلات مرتبة بالعنوان.
 *  - "المضاف حديثًا"  => آخر ما أضيف / تم تحديثه.
 *  - "السنة"          => حسب yearFilter.
 */
public class ShowsListRepository {

    private static final String TAG = "ShowsListRepository";

    private final AppDatabase db;
    private final PlexApiClient plexApiClient;

    public ShowsListRepository(Context context) {
        this.db = AppDatabase.getInstance(context.getApplicationContext());
        this.plexApiClient = new PlexApiClient();
    }

    public interface Callback {
        void onResult(List<LibraryItem> list, Exception error);
    }

    public void getShowsForSectionAsync(String sectionKey,
                                        String mode,
                                        String yearFilter,
                                        Callback callback) {
        new Thread(() -> {
            try {
                long now = System.currentTimeMillis();

                // 1) قراءة من الكاش وعرضه مباشرة لو موجود (عرض أولي سريع)
                List<LibraryShowEntity> cached = db.libraryShowDao().getShowsForSection(sectionKey);
                List<LibraryItem> cachedItems = mapEntitiesToLibraryItems(cached);

                Log.d(TAG, "section=" + sectionKey
                        + " mode=" + mode
                        + " cachedSize=" + cachedItems.size());

                if (callback != null && !cachedItems.isEmpty()) {
                    callback.onResult(cachedItems, null);
                }

                // 2) جلب من Plex دائماً حسب المود (لا نعتمد على TTL الآن لتبسيط السلوك)
                List<LibraryItem> fresh;

                if ("المضاف حديثًا".equals(mode)) {
                    // آخر المسلسلات التي تم إضافتها/تحديثها في Plex
                    fresh = plexApiClient.getRecentlyAddedShows(sectionKey);

                } else if ("السنة".equals(mode)
                        && yearFilter != null
                        && !yearFilter.isEmpty()) {

                    // مسلسلات سنة معيّنة + ترتيب أبجدي
                    String sortQuery = "?year=" + yearFilter + "&sort=titleSort:asc";
                    fresh = plexApiClient.getLibraryItems(sectionKey, sortQuery);

                } else {
                    // "الكل (أ - ي)" أو مود غير معروف => نعتبره "الكل"
                    // نجلب كل المسلسلات مرتبة بالعنوان
                    fresh = plexApiClient.getLibraryItems(
                            sectionKey,
                            "?sort=titleSort:asc");
                }

                Log.d(TAG, "section=" + sectionKey
                        + " mode=" + mode
                        + " freshSize=" + (fresh != null ? fresh.size() : -1));

                if (fresh == null) {
                    // لو لم يأت شيء من Plex:
                    // لو عندنا كاش سبق وأعدناه، نكتفي به. وإلا نرجع خطأ.
                    if (callback != null && cachedItems.isEmpty()) {
                        callback.onResult(null, new Exception("null result from Plex"));
                    }
                    return;
                }

                // 3) تحديث Room بالقائمة الجديدة (تمثل الحالة الحالية للقسم)
                List<LibraryShowEntity> toStore = mapLibraryItemsToEntities(sectionKey, fresh, now);

                db.libraryShowDao().clearSection(sectionKey);
                db.libraryShowDao().insertOrUpdateAll(toStore);

                // 4) إرجاع القائمة المحدثة
                if (callback != null) {
                    callback.onResult(fresh, null);
                }

            } catch (Exception e) {
                Log.e(TAG, "getShowsForSectionAsync error", e);
                if (callback != null) {
                    callback.onResult(null, e);
                }
            }
        }).start();
    }

    // تحويل الكيانات المخزّنة إلى LibraryItem لعرضها في الـ UI
    private List<LibraryItem> mapEntitiesToLibraryItems(List<LibraryShowEntity> entities) {
        List<LibraryItem> list = new ArrayList<>();
        if (entities == null) return list;
        for (LibraryShowEntity e : entities) {
            list.add(new LibraryItem(
                    e.ratingKey,
                    e.title,
                    e.year,
                    e.thumb,
                    "show"
            ));
        }
        return list;
    }

    // تحويل LibraryItem إلى كائنات Room للحفظ
    private List<LibraryShowEntity> mapLibraryItemsToEntities(String sectionKey,
                                                              List<LibraryItem> items,
                                                              long updatedAt) {
        List<LibraryShowEntity> list = new ArrayList<>();
        if (items == null) return list;
        for (LibraryItem item : items) {
            if (!"show".equals(item.getType())) continue;

            LibraryShowEntity e = new LibraryShowEntity();
            e.ratingKey = item.getRatingKey();
            e.sectionKey = sectionKey;
            e.title = item.getTitle();
            e.year = item.getYear();
            e.thumb = item.getThumb();
            e.updatedAt = updatedAt;
            list.add(e);
        }
        return list;
    }
}
